far=float(input("digite o grau de fahrenheit:"))
cel=5*(far-32)/9
print(" temperatura em graus Celsius",cel)

print("isso", "é","um","teste")


print("Essa mensagem aparece na primeira linha \nEnquanto essa aparece na segunda")

x=10
print("O quadrado do número",x,"é igual a",x**2,sep="_")


print("Vou imprimir isso em uma linha",end='')
print(" continuarei na linha de cima")



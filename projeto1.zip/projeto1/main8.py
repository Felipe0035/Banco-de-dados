quanti = float(input("digite a quantidade de pães:"))
qaunti2 = float(input("digite la quntidad de broa:"))
pao = quanti*0.80
broa = qaunti2*2.50
total = pao+broa
fabri = ((total*43)/100)
restante = total-fabri
poupa = ((restante*15)/100)
euro = (restante-poupa)/4.60

print("a quantidade de pães diarios é de =",pao)
print("quantide de broas vendidas é de =",broa)
print("a venda total de broas e pães são de =",total)
print("o custo de fabricação é de = R$",fabri)
print("na poupança ficara = R$",poupa)
print("comprando assim =",euro,"euros")
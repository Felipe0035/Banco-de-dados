#Faça um programa  que peça o raio de um círculo, calcule e mostre sua área.

raio= float(input("Digite o raio do circulo:"))
area= 3.1415*raio**2
print("O círculo de raio",raio, " tem area igual",area)

altura=float(input("Digite a altura da parede:"))
comprimento=float(input("Digite o comprimento da parede:"))

area_da_parede= altura*comprimento
lata_metro=10.8
lata_preco=107

quant_lata= area_da_parede //lata_metro
preco_da_lata=quant_lata*lata_preco

print("Quantidades de latas foram de",quant_lata,"\nPreço total das latas é de:",preco_da_lata)
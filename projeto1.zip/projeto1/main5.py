salario=float(input("digite o salário bruto:"))
imposto= (0.11*salario)
INSS=  (0.08*salario)
sindicato=  (0.05*salario)

total_desconto=imposto+INSS+sindicato
salario_liquido= salario-total_desconto
print("O desconto de imposto é de",imposto,"\nO desconto do INSS é de",INSS,"\nO desconto do sindicato é de",sindicato,"\nSeu salário bruto é de",salario_liquido)
#Faça um programa, que soma um com outro.

numero1=int(input("Digite o número inteiro:"))
numero2=int(input("Digite o número inteiro:"))
soma= numero1 + numero2

print("A soma dos números foi", soma)

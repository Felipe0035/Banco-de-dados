numero_inteiro1=int(input("Digite o numero inteiro:"))
numero_inteiro2=int(input("Digite o numero inteiro:"))
numero_real= float(input("Digite o numero real:"))

produto=(2*numero_inteiro1)*(numero_inteiro2/2)
soma=(3*numero_inteiro1)+numero_real
triplo=(numero_real **3)

print("O produto foi",produto, "\nA soma foi",soma,"\ngElevado ao cubo",triplo)
